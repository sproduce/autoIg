<?php

namespace App\Repositories;
use App\Repositories\Interfaces\BrandRepositoryInterface;
use App\Models\carBrand;

class BrandRepository implements BrandRepositoryInterface
{
    
    function __construct(carBrand $carBrand){

    }


    public function getBrandByLetter($letter){

    }

    public function getBrandByName($brandName){

        return $carBrand::where('name','$brandName')->get();
    }


    public function saveBrand($brandName){
        $carBrand=new carBrand();
        $carBrand->name=$brandName;
        $carBrand->save();
    }

}
