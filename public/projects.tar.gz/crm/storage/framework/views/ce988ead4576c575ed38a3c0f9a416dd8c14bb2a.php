<?php $__env->startSection('header'); ?>


            <h6>Марки машин</h6>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($brands->count()): ?>
        есть данные
    <?php else: ?>
        <div class="row">
            <div class="col-12 text-center">
                <h5>Марки не добавлены</h5>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-12 text-center mt-4" >
            <?php $__currentLoopData = range('A','Z'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="/reference/brand?letter=<?php echo e($letter); ?>"><?php echo e($letter); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <a class="btn btn-ssm btn-outline-success DialogUserSMin" title="Добавить производителя" href="/dialog/addBrand"><i class="far fa-plus-square"></i></a>
            <a class="btn btn-ssm btn-outline-success DialogUserSMin" title="Добавить список производителей" href="/dialog/addBrandGroup"><i class="fas fa-folder-plus"></i></a>
        </div>
    </div>




<?php $__env->stopSection(); ?>



<?php echo $__env->make('../adminIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/crm/resources/views/reference/brandList.blade.php ENDPATH**/ ?>